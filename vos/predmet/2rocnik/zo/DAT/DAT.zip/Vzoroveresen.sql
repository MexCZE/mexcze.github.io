-- Vytvoření schématu 'cviceni'
CREATE SCHEMA cviceni;
GO

-- Tabulka Studenti
CREATE TABLE cviceni.Studenti (
    StudentID INT IDENTITY(1,1) PRIMARY KEY,
    Jmeno VARCHAR(50) NOT NULL,
    Prijmeni VARCHAR(50) NOT NULL,
    DatumNarozeni DATE NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Telefon CHAR(10)
);

-- Tabulka Kurzy
CREATE TABLE cviceni.Kurzy (
    KurzID INT IDENTITY(1,1) PRIMARY KEY,
    Nazev VARCHAR(100) NOT NULL,
    Popis TEXT,
    Kredity INT NOT NULL,
    Semestr CHAR(6) NOT NULL, -- Např. 'ZS2024' nebo 'LS2024'
    VyucujiciID INT NOT NULL,
    CONSTRAINT FK_Kurzy_Vyucujici FOREIGN KEY (VyucujiciID) REFERENCES cviceni.Vyucujici(VyucujiciID)
);

-- Tabulka Vyučující
CREATE TABLE cviceni.Vyucujici (
    VyucujiciID INT IDENTITY(1,1) PRIMARY KEY,
    Jmeno VARCHAR(50) NOT NULL,
    Prijmeni VARCHAR(50) NOT NULL,
    Titul VARCHAR(20),
    Email VARCHAR(100) UNIQUE NOT NULL,
    Telefon CHAR(10)
);

-- Tabulka Zápisy
CREATE TABLE cviceni.Zapisy (
    ZapisID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT NOT NULL,
    KurzID INT NOT NULL,
    DatumZapsani DATE NOT NULL CHECK (MONTH(DatumZapsani) = 9 AND DAY(DatumZapsani) BETWEEN 1 AND 7),
    Status CHAR(1) CHECK (Status IN ('A', 'N', 'D')), -- 'A' = Aktivní, 'N' = Neaktivní, 'D' = Dokončeno
    CONSTRAINT FK_Zapisy_Studenti FOREIGN KEY (StudentID) REFERENCES cviceni.Studenti(StudentID),
    CONSTRAINT FK_Zapisy_Kurzy FOREIGN KEY (KurzID) REFERENCES cviceni.Kurzy(KurzID),
    CONSTRAINT UQ_StudentKurz UNIQUE (StudentID, KurzID) -- Každý student může zapsat kurz pouze jednou
);

-- Tabulka Hodnocení
CREATE TABLE cviceni.Hodnoceni (
    HodnoceniID INT IDENTITY(1,1) PRIMARY KEY,
    ZapisID INT NOT NULL,
    Hodnoceni INT CHECK (Hodnoceni IN (1, 2, 3, 5)),
    Poznamka TEXT,
    CONSTRAINT FK_Hodnoceni_Zapisy FOREIGN KEY (ZapisID) REFERENCES cviceni.Zapisy(ZapisID)
);
GO
